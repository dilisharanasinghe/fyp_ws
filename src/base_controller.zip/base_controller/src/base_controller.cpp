#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float32MultiArray.h>

#define KINECT_BASE_ANGLE -1.22

class baseController{
  public:
    baseController(){
      ros::NodeHandle nh_;
      sub_ = nh_.subscribe("base_controller_data", 1000, &baseController::baseCallback,this);
      pub_ = nh_.advertise<nav_msgs::Odometry>("odom", 50);


    } 

    void baseCallback(const std_msgs::Float32MultiArray::ConstPtr& msg)
    {
      double x = msg->data[0];
      double y = msg->data[1];
      double th = msg->data[2];
      double vx = msg->data[3];
      double vth = msg->data[4];
	  double pitch = msg->data[5];

	  //---------------odom_base_link-----------------------------------------

      geometry_msgs::TransformStamped odom_trans;
      odom_trans.header.stamp = ros::Time::now();
      odom_trans.header.frame_id = "odom";
      odom_trans.child_frame_id = "base_link";

      odom_trans.transform.translation.x = x;
      odom_trans.transform.translation.y = y;
      odom_trans.transform.translation.z = 0.0;
      odom_trans.transform.rotation =  tf::createQuaternionMsgFromYaw(th);

      //send the transform
      odom_broadcaster_.sendTransform(odom_trans);
	  //----------------------------------------------------------------------
	  
	  //-------------base_link_to_pitch_link---------------------------------
      odom_trans.header.stamp = ros::Time::now();
      odom_trans.header.frame_id = "base_link";
      odom_trans.child_frame_id = "pitch_link";

      odom_trans.transform.translation.x = 0.0;
      odom_trans.transform.translation.y = 0.0;
      odom_trans.transform.translation.z = 0.0;
      odom_trans.transform.rotation =  tf::createQuaternionMsgFromRollPitchYaw(0,(pitch - KINECT_BASE_ANGLE)*M_PI/180.0,0);

      //send the transform
      odom_broadcaster_.sendTransform(odom_trans);
	  //-----------------------------------------------------------------------

      nav_msgs::Odometry odom;
      odom.header.stamp = ros::Time::now();
      odom.header.frame_id = "odom";

      //set the position
      odom.pose.pose.position.x = x;
      odom.pose.pose.position.y = y;
      odom.pose.pose.position.z = 0.0;
      odom.pose.pose.orientation = tf::createQuaternionMsgFromYaw(th);

      //set the velocity
      odom.child_frame_id = "base_link";
      odom.twist.twist.linear.x = vx;
      odom.twist.twist.linear.y = 0;
      odom.twist.twist.angular.z = vth;

      //publish the message
      pub_.publish(odom);

    }


  protected:
    ros::Subscriber sub_;
    ros::Publisher pub_;
    tf::TransformBroadcaster odom_broadcaster_;


};



int main(int argc, char** argv){
  ros::init(argc, argv, "odometry_publisher");

  baseController base_controller;

  ros::spin();
  
}
